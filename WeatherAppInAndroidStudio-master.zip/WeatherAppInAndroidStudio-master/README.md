# WeatherAppInAndroidStudio
This is amazing weather app which uses open weather api and it can fetch the weather of your current location or any particular city. The UI of the app is completely responsive and you can also watch the detailed tutorial on my Channel


![Copy of seek bar (3)](https://user-images.githubusercontent.com/64765400/103085628-1c2cac00-4597-11eb-9c40-3d1663e0a39a.png)
